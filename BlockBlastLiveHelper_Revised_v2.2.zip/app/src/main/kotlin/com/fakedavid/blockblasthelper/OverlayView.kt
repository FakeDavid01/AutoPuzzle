package com.fakedavid.blockblasthelper

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class OverlayView(context: Context) : View(context) {

    var detection: Detection? = null
        set(value) { field = value; invalidate() }

    var moves: List<Solver.Move> = emptyList()
        set(value) { field = value; invalidate() }

    private var ox = 0f
    private var oy = 0f
    private var scale = 1f
    private var lastX = 0f
    private var lastY = 0f
    private var resizing = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.rgb(80, 230, 150)
    }

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = detection ?: return
        if (moves.isEmpty()) return

        val r = d.boardRect
        val cw = (r.right - r.left) / 8f
        val ch = (r.bottom - r.top) / 8f

        c.save()
        c.translate(ox, oy)
        c.scale(scale, scale)

        for ((i, m) in moves.withIndex()) {
            val color = when (i) {
                0 -> Color.argb(150, 50, 220, 120)
                1 -> Color.argb(150, 70, 140, 255)
                else -> Color.argb(150, 255, 180, 40)
            }
            paint.color = color
            paint.style = Paint.Style.FILL
            for ((dr, dc) in m.piece.cells) {
                val left = r.left + (m.col + dc) * cw
                val top = r.top + (m.row + dr) * ch
                c.drawRoundRect(left + 3, top + 3, left + cw - 3, top + ch - 3, 9f, 9f, paint)
            }
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            val left = r.left + m.col * cw
            val top = r.top + m.row * ch
            c.drawRect(
                left + 2, top + 2,
                left + max(cw, cw * (m.piece.cells.maxOfOrNull { it.second + 1 } ?: 1)) - 2,
                top + max(ch, ch * (m.piece.cells.maxOfOrNull { it.first + 1 } ?: 1)) - 2,
                paint
            )
        }

        // Drag/resize frame.
        val frame = RectF(r.left - 16, r.top - 16, r.right + 16, r.bottom + 16)
        c.drawRoundRect(frame, 18f, 18f, border)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(210, 20, 25, 38)
        c.drawRoundRect(frame.left, frame.top, frame.left + 165, frame.top + 42, 12f, 12f, paint)
        paint.color = Color.WHITE
        paint.textSize = 20f
        c.drawText("LIVE  ${(d.confidence * 100).toInt()}%", frame.left + 12, frame.top + 28, paint)

        paint.color = Color.WHITE
        c.drawCircle(frame.right, frame.bottom, 18f, paint)
        paint.color = Color.rgb(20, 25, 38)
        c.drawCircle(frame.right, frame.bottom, 10f, paint)

        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
                val d = detection ?: return true
                val r = d.boardRect
                val handleX = ox + (r.right + 16) * scale
                val handleY = oy + (r.bottom + 16) * scale
                resizing = ((e.rawX - handleX) * (e.rawX - handleX) +
                        (e.rawY - handleY) * (e.rawY - handleY)) < 42f * 42f
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - lastX
                val dy = e.rawY - lastY
                if (resizing) {
                    scale = (scale + (dx + dy) / 900f).coerceIn(.55f, 2.2f)
                } else {
                    ox += dx
                    oy += dy
                }
                lastX = e.rawX
                lastY = e.rawY
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                resizing = false
                return true
            }
        }
        return true
    }
}
