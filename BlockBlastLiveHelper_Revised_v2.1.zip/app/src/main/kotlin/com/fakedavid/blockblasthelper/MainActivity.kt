package com.fakedavid.blockblasthelper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                startCapture(result.resultCode, result.data!!)
            } else {
                status.text = "Izin rekam layar dibatalkan."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(11, 16, 32))
        }

        val title = TextView(this).apply {
            text = "BLOCK BLAST\nLIVE HELPER"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val subtitle = TextView(this).apply {
            text = "v2.0 • Live detector + solver + resizable overlay"
            textSize = 14f
            setTextColor(Color.rgb(160, 174, 196))
            setPadding(0, 8, 0, 28)
        }

        status = TextView(this).apply {
            text = "Status: belum aktif"
            textSize = 16f
            setTextColor(Color.rgb(220, 228, 240))
            setPadding(0, 8, 0, 20)
        }

        val overlay = makeButton("1  IZINKAN OVERLAY") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } else {
                status.text = "Overlay sudah diizinkan ✓"
            }
        }

        val start = makeButton("2  MULAI LIVE CAPTURE") {
            if (!Settings.canDrawOverlays(this)) {
                status.text = "Izinkan overlay dulu."
                return@makeButton
            }
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            captureLauncher.launch(mgr.createScreenCaptureIntent())
        }

        val stop = makeButton("STOP") {
            stopService(Intent(this, CaptureService::class.java))
            status.text = "Status: berhenti"
        }

        val info = TextView(this).apply {
            text = """
                DETEKTOR BARU

                • Mencari papan 8×8 secara adaptif.
                • Mengukur warna/brightness per sel, bukan satu threshold tetap.
                • Mencari bentuk blok dari area tray bawah.
                • Confidence ditampilkan pada overlay.
                • Overlay dapat digeser dan diubah ukurannya.
                • Ada kalibrasi manual jika auto-detect meleset.

                Catatan: Android meminta izin rekam layar karena helper membaca frame secara lokal.
            """.trimIndent()
            textSize = 14f
            setTextColor(Color.rgb(160, 174, 196))
            setPadding(0, 28, 0, 0)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(overlay)
        root.addView(start)
        root.addView(stop)
        root.addView(info)

        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(45, 55, 80))
            gravity = Gravity.CENTER
            setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, 6, 0, 6)
            layoutParams = lp
        }

    private fun startCapture(resultCode: Int, data: Intent) {
        val intent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_RESULT_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        status.text = "Status: LIVE aktif • buka Block Blast."
    }
}
