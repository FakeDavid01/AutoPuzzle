package com.fakedavid.blockblasthelper

object Solver {

    data class Move(val row: Int, val col: Int, val piece: DetectedPiece, val clears: Int, val score: Int)

    fun best(board: Array<BooleanArray>, pieces: List<DetectedPiece>): List<Move> {
        if (pieces.isEmpty()) return emptyList()
        var bestMoves: List<Move> = emptyList()
        var bestScore = Int.MIN_VALUE

        fun dfs(
            index: Int,
            current: Array<BooleanArray>,
            moves: MutableList<Move>,
            score: Int
        ) {
            if (index == pieces.size) {
                if (score > bestScore) {
                    bestScore = score
                    bestMoves = moves.toList()
                }
                return
            }
            val p = pieces[index]
            var placed = false
            for (r in 0 until 8) for (c in 0 until 8) {
                if (!fits(current, p, r, c)) continue
                placed = true
                val next = copy(current)
                place(next, p, r, c)
                val cleared = clearLines(next)
                val move = Move(r, c, p, cleared, cleared * 100 - r * 2 - c)
                moves.add(move)
                dfs(index + 1, next, moves, score + move.score + p.cells.size * 3)
                moves.removeAt(moves.lastIndex)
            }
            if (!placed) {
                // A sequence may legitimately end before all 3 pieces fit.
                if (score > bestScore) {
                    bestScore = score
                    bestMoves = moves.toList()
                }
            }
        }

        dfs(0, copy(board), mutableListOf(), 0)
        return bestMoves
    }

    private fun fits(b: Array<BooleanArray>, p: DetectedPiece, r: Int, c: Int): Boolean =
        p.cells.all {
            val rr = r + it.first
            val cc = c + it.second
            rr in 0..7 && cc in 0..7 && !b[rr][cc]
        }

    private fun place(b: Array<BooleanArray>, p: DetectedPiece, r: Int, c: Int) {
        for ((dr, dc) in p.cells) b[r + dr][c + dc] = true
    }

    private fun clearLines(b: Array<BooleanArray>): Int {
        val rows = (0 until 8).filter { r -> (0 until 8).all { c -> b[r][c] } }
        val cols = (0 until 8).filter { c -> (0 until 8).all { r -> b[r][c] } }
        for (r in rows) for (c in 0 until 8) b[r][c] = false
        for (c in cols) for (r in 0 until 8) b[r][c] = false
        return rows.size + cols.size
    }

    private fun copy(b: Array<BooleanArray>) = Array(8) { r -> b[r].clone() }
}
