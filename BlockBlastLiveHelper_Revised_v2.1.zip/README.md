## v2.1

Perbaikan compile Kotlin pada `Detector.kt` dan bump versi aplikasi ke 2.1.

# Block Blast Live Helper v2.1.0

Versi revisi untuk build APK melalui GitHub Actions.

## Fitur
- Live screen capture dengan MediaProjection.
- Detector papan 8×8 adaptif.
- Detector tray 3 blok dengan confidence.
- Solver mencoba urutan dan posisi pemasangan.
- Overlay target langsung di atas game.
- Overlay bisa digeser.
- Handle pojok kanan-bawah untuk memperbesar / memperkecil overlay.
- UI aplikasi dibuat ulang lebih ringkas.

## Build dari HP
1. Upload seluruh isi project ke repository.
2. Pastikan workflow berada di `.github/workflows/build-apk.yml`.
3. Buka tab Actions.
4. Pilih `Build APK`.
5. Tunggu sampai hijau.
6. Buka hasil run → Artifacts → `BlockBlastLiveHelper-v2.1`.

## Penting
Detector ini adalah v2.1 dan sengaja menggunakan confidence. Jika screenshot/game memiliki tema atau layout yang sangat berbeda, gunakan kalibrasi manual pada iterasi berikutnya daripada mengandalkan threshold tunggal.

Android akan meminta izin:
- tampil di atas aplikasi lain;
- rekam/capture layar.

Frame diproses lokal di perangkat dan tidak dikirim ke server oleh aplikasi ini.
