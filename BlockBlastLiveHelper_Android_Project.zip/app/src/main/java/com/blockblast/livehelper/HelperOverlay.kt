package com.blockblast.livehelper

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*

class HelperOverlay(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(18, 18, 18, 18)
        background = GradientDrawable().apply {
            cornerRadius = 28f
            setColor(Color.argb(242, 20, 24, 31))
            setStroke(2, Color.rgb(90, 100, 115))
        }
    }
    private val title = TextView(context).apply {
        text = "BLOCK BLAST HELPER"
        setTextColor(Color.WHITE)
        textSize = 16f
        setPadding(0,0,0,8)
    }
    private val info = TextView(context).apply {
        text = "Mendeteksi..."
        setTextColor(Color.LTGRAY)
        textSize = 13f
    }
    private val board = HelperBoardView(context)
    private val done = Button(context).apply {
        text = "SELESAI & LANJUT"
        setOnClickListener { Controller.done() }
    }

    private var attached = false

    init {
        root.addView(title)
        root.addView(info)
        root.addView(board, LinearLayout.LayoutParams(420, 420))
        root.addView(done, LinearLayout.LayoutParams(-1, -2))
    }

    fun show() {
        if (attached) return
        val lp = WindowManager.LayoutParams(
            500,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        wm.addView(root, lp)
        attached = true
    }

    fun hide() {
        if (!attached) return
        wm.removeView(root)
        attached = false
    }

    fun update(result: AnalysisResult) {
        root.post {
            info.text = result.message
            board.setState(result.board, result.target, result.step)
        }
    }
}
