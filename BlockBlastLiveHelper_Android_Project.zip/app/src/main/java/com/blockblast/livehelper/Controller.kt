package com.blockblast.livehelper

object Controller {
    private var currentStep = 0

    fun done() {
        currentStep = (currentStep + 1) % 3
        ScreenAnalyzer.advance(currentStep)
    }

    fun step() = currentStep
}
