package com.blockblast.livehelper

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.min

class HelperBoardView(context: Context) : View(context) {
    private var board = Array(8) { BooleanArray(8) }
    private var target = emptyList<Pair<Int,Int>>()
    private var step = 0

    fun setState(b: Array<BooleanArray>, t: List<Pair<Int,Int>>, s: Int) {
        board = b.map { it.clone() }.toTypedArray()
        target = t
        step = s
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val size = min(width, height)
        val cell = size / 8f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL

        for (r in 0 until 8) for (col in 0 until 8) {
            p.color = if (board[r][col]) Color.rgb(75,82,94) else Color.rgb(39,44,53)
            c.drawRoundRect(
                col*cell+3, r*cell+3, (col+1)*cell-3, (r+1)*cell-3,
                10f,10f,p
            )
        }

        p.color = Color.rgb(255, 205, 70)
        for ((r,col) in target) {
            c.drawRoundRect(
                col*cell+6, r*cell+6, (col+1)*cell-6, (r+1)*cell-6,
                10f,10f,p
            )
        }

        p.color = Color.WHITE
        p.textSize = cell * .22f
        p.textAlign = Paint.Align.CENTER
        c.drawText(
            when(step) { 0 -> "BLOCK 1"; 1 -> "BLOCK 2"; 2 -> "BLOCK 3"; else -> "NEXT" },
            size/2f, size+0f, p
        )
    }
}
