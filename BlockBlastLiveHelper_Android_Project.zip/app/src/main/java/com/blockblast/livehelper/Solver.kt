package com.blockblast.livehelper

object Solver {
    fun bestPlacement(board: Array<BooleanArray>, piece: Piece): List<Pair<Int, Int>> {
        var best = emptyList<Pair<Int, Int>>()
        var bestScore = Int.MIN_VALUE

        if (piece.width > 8 || piece.height > 8) return best

        for (r in 0..8 - piece.height) for (c in 0..8 - piece.width) {
            val cells = mutableListOf<Pair<Int, Int>>()
            var ok = true

            for (pr in 0 until piece.height) for (pc in 0 until piece.width) {
                if (!piece.cells[pr * piece.width + pc]) continue
                if (board[r + pr][c + pc]) ok = false
                cells.add(r + pr to c + pc)
            }

            if (!ok || cells.isEmpty()) continue

            val score = score(board, cells)
            if (score > bestScore) {
                bestScore = score
                best = cells
            }
        }
        return best
    }

    private fun score(board: Array<BooleanArray>, cells: List<Pair<Int, Int>>): Int {
        val b = Array(8) { board[it].clone() }
        for ((r, c) in cells) b[r][c] = true

        var cleared = 0
        for (r in 0 until 8) if (b[r].all { it }) cleared++
        for (c in 0 until 8) if ((0 until 8).all { b[it][c] }) cleared++

        var holes = 0
        var filled = 0
        for (r in 0 until 8) for (c in 0 until 8) {
            if (b[r][c]) filled++ else holes++
        }

        // Strongly reward immediate clears, mildly reward compact occupancy.
        return cleared * 10000 - holes + filled
    }
}
