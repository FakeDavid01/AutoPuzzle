package com.blockblast.livehelper

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

data class Piece(val width: Int, val height: Int, val cells: BooleanArray)

data class AnalysisResult(
    val board: Array<BooleanArray>,
    val target: List<Pair<Int,Int>>,
    val step: Int,
    val message: String
)

object ScreenAnalyzer {
    private var board = Array(8) { BooleanArray(8) }
    private var pieces = mutableListOf<Piece>()
    private var lastSignature = Long.MIN_VALUE
    private var currentStep = 0

    // Normalized coordinates for the common Block Blast layout.
    private const val BOARD_L = 0.055f
    private const val BOARD_T = 0.238f
    private const val BOARD_R = 0.947f
    private const val BOARD_B = 0.642f
    private const val TRAY_T = 0.675f
    private const val TRAY_B = 0.84f

    fun advance(step: Int) {
        currentStep = step.coerceIn(0, 2)
    }

    fun analyze(src: Bitmap): AnalysisResult {
        board = detectBoard(src)
        val detected = detectPieces(src)
        val sig = signature(detected)

        // A changed tray means a new round. This resets to Block 1 automatically.
        if (detected.size == 3 && sig != lastSignature) {
            pieces = detected.toMutableList()
            lastSignature = sig
            currentStep = 0
        }

        val piece = pieces.getOrNull(currentStep)
        val target = if (piece != null) Solver.bestPlacement(board, piece) else emptyList()

        val msg = when {
            pieces.size < 3 -> "Mencari 3 blok..."
            target.isEmpty() -> "Tidak ada placement untuk Block ${currentStep + 1}."
            else -> "Block ${currentStep + 1}: pasang sesuai kotak kuning."
        }
        return AnalysisResult(board, target, currentStep, msg)
    }

    private fun detectBoard(bmp: Bitmap): Array<BooleanArray> {
        val out = Array(8) { BooleanArray(8) }
        val w = bmp.width
        val h = bmp.height
        val l = (w * BOARD_L).toInt()
        val t = (h * BOARD_T).toInt()
        val r = (w * BOARD_R).toInt()
        val btm = (h * BOARD_B).toInt()
        val cw = (r - l) / 8f
        val ch = (btm - t) / 8f

        for (row in 0 until 8) for (col in 0 until 8) {
            // Sample a small cross around the cell center. Majority vote is
            // less sensitive to grid lines and rounded cell corners.
            var hit = 0
            var samples = 0
            for (dx in -2..2 step 2) for (dy in -2..2 step 2) {
                val x = (l + (col + .5f) * cw + dx).toInt().coerceIn(0, w - 1)
                val y = (t + (row + .5f) * ch + dy).toInt().coerceIn(0, h - 1)
                if (isOccupiedCell(bmp.getPixel(x, y))) hit++
                samples++
            }
            out[row][col] = hit >= samples * 0.55
        }
        return out
    }

    private fun isOccupiedCell(rgb: Int): Boolean {
        val r = Color.red(rgb)
        val g = Color.green(rgb)
        val b = Color.blue(rgb)
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val chroma = mx - mn
        return (chroma > 55 && mx > 105) || mx > 205
    }

    private fun detectPieces(bmp: Bitmap): List<Piece> {
        val w = bmp.width
        val h = bmp.height
        val y0 = (h * TRAY_T).toInt()
        val y1 = (h * TRAY_B).toInt()
        val centers = floatArrayOf(.23f, .50f, .77f)
        val result = mutableListOf<Piece>()

        // Each slot is represented by a 5x5 logical sampling grid.
        for (cxN in centers) {
            val cx = (w * cxN).toInt()
            val mask = BooleanArray(25)
            var any = false

            for (rr in 0 until 5) for (cc in 0 until 5) {
                val x = (cx + (cc - 2) * w * .045f).toInt().coerceIn(0, w - 1)
                val y = (y0 + (rr + .5f) * (y1 - y0) / 5f).toInt().coerceIn(0, h - 1)
                val colored = isPiecePixel(bmp.getPixel(x, y))
                mask[rr * 5 + cc] = colored
                any = any || colored
            }
            if (any) result.add(normalize(mask))
        }
        return result
    }

    private fun isPiecePixel(rgb: Int): Boolean {
        val r = Color.red(rgb)
        val g = Color.green(rgb)
        val b = Color.blue(rgb)
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        return (mx - mn > 60 && mx > 115) || mx > 210
    }

    private fun normalize(m: BooleanArray): Piece {
        var minR = 5; var maxR = -1
        var minC = 5; var maxC = -1
        for (r in 0 until 5) for (c in 0 until 5) {
            if (!m[r * 5 + c]) continue
            minR = min(minR, r); maxR = max(maxR, r)
            minC = min(minC, c); maxC = max(maxC, c)
        }
        if (maxR < 0) return Piece(1, 1, booleanArrayOf(true))

        val height = maxR - minR + 1
        val width = maxC - minC + 1
        val cells = BooleanArray(width * height)
        for (r in 0 until height) for (c in 0 until width) {
            cells[r * width + c] = m[(minR + r) * 5 + minC + c]
        }
        return Piece(width, height, cells)
    }

    private fun signature(pieces: List<Piece>): Long {
        var x = 17L
        for (p in pieces) {
            x = x * 31 + p.width
            x = x * 31 + p.height
            for (v in p.cells) x = x * 31 + if (v) 1 else 0
        }
        return x
    }
}
