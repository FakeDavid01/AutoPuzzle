package com.blockblast.livehelper

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val captureRequest = 9001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val status = findViewById<TextView>(R.id.status)
        val overlay = findViewById<Button>(R.id.overlayButton)
        val start = findViewById<Button>(R.id.startButton)
        val stop = findViewById<Button>(R.id.stopButton)

        overlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            }
        }

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                status.text = "Aktifkan izin overlay dulu."
                return@setOnClickListener
            }
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
        }

        stop.setOnClickListener {
            stopService(Intent(this, CaptureService::class.java))
            status.text = "Live capture dihentikan."
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != captureRequest || resultCode != Activity.RESULT_OK || data == null) return

        val service = Intent(this, CaptureService::class.java).apply {
            putExtra("resultCode", resultCode)
            putExtra("resultData", data)
        }
        startForegroundService(service)
        findViewById<TextView>(R.id.status).text =
            "LIVE AKTIF — buka Block Blast. Helper akan muncul sebagai papan terpisah."
    }
}
