# Block Blast Live Helper — Android

Project ini dibuat untuk **Android-only** dan dibangun otomatis lewat GitHub Actions.

## Fitur

- MediaProjection untuk membaca layar game secara live.
- Foreground service untuk mempertahankan capture.
- Helper berupa **papan 8×8 terpisah**, bukan coretan di screenshot.
- Deteksi papan dan tiga slot blok secara periodik.
- Alur `BLOCK 1 → SELESAI → BLOCK 2 → SELESAI → BLOCK 3 → SELESAI`.
- Setelah tray berubah, helper kembali ke Block 1 tanpa meminta screenshot baru.
- Solver tidak memutar bentuk secara otomatis.

## Penting

Deteksi visual sangat bergantung pada layout/tema/versi Block Blast. Engine ini membaca layar secara live; pengguna tidak perlu mengambil screenshot baru setiap blok. Versi awal ini memakai koordinat layar yang dinormalisasi dan threshold warna konservatif. Jadi ini adalah **buildable live-helper engine**, tetapi belum bisa dijamin 100% akurat untuk setiap perangkat tanpa kalibrasi pada screenshot nyata.

Untuk Android 14+, MediaProjection foreground service harus mendeklarasikan permission/type yang sesuai dan izin rekam layar harus diberikan oleh pengguna.

## Build dari HP

1. Buat repository GitHub baru.
2. Upload seluruh isi project ini.
3. Buka tab **Actions**.
4. Jalankan workflow **Build APK**.
5. Setelah selesai, buka hasil workflow dan download artifact `block-blast-helper-debug`.
6. Ekstrak ZIP artifact lalu instal APK di Android.

GitHub Actions menyimpan hasil build sebagai workflow artifact.

## Pemakaian

1. Instal APK.
2. Tekan `IZINKAN OVERLAY`.
3. Tekan `MULAI LIVE CAPTURE`.
4. Setujui dialog rekam layar Android.
5. Buka Block Blast.
6. Helper akan muncul sebagai papan terpisah.
7. Pasang Block 1 sesuai target → tekan `SELESAI & LANJUT`.
8. Lakukan hal yang sama untuk Block 2 dan Block 3.
9. Setelah tiga blok selesai, tray baru dibaca otomatis dari live capture.

## Kalibrasi

Jika pada perangkat tertentu papan/slot tidak terdeteksi, edit konstanta berikut:

`app/src/main/java/com/blockblast/livehelper/ScreenAnalyzer.kt`

- `BOARD_L`
- `BOARD_T`
- `BOARD_R`
- `BOARD_B`
- `TRAY_T`
- `TRAY_B`

Semua bernilai relatif terhadap lebar/tinggi layar, jadi tidak perlu memasukkan resolusi manual.
