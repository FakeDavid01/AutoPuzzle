package com.fakedavid.blockblasthelper

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class RectF2(val left: Float, val top: Float, val right: Float, val bottom: Float)
data class DetectedPiece(val cells: List<Pair<Int, Int>>, val confidence: Float)
data class Detection(
    val board: Array<BooleanArray>,
    val boardRect: RectF2,
    val pieces: List<DetectedPiece>,
    val confidence: Float
)

object Detector {

    /*
     * Adaptive detector designed for Block Blast-like screens.
     * It intentionally returns confidence instead of pretending every frame is correct.
     */
    fun detect(bitmap: Bitmap): Detection? {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 300 || h < 500) return null

        val boardRect = findBoard(bitmap) ?: return null
        val board = sampleBoard(bitmap, boardRect)
        val pieces = detectTray(bitmap)

        val boardScore = board.flatMap { it.asList() }.count { it }.let {
            // Real boards normally contain some occupied and some empty cells.
            if (it in 1..63) 1f else 0.35f
        }
        val pieceScore = if (pieces.isNotEmpty()) 1f else 0.25f

        return Detection(
            board = board,
            boardRect = boardRect,
            pieces = pieces,
            confidence = ((boardScore * .7f) + (pieceScore * .3f)).coerceIn(0f, 1f)
        )
    }

    private fun findBoard(b: Bitmap): RectF2? {
        val w = b.width.toFloat()
        val h = b.height.toFloat()

        // Search the common central playfield band, but derive its edges from
        // horizontal/vertical brightness/color changes instead of hardcoding one device size.
        val yStart = (h * .18f).toInt()
        val yEnd = (h * .72f).toInt()
        var best: RectF2? = null
        var bestScore = 0f

        val minSide = min(w, h)
        val expected = minSide * .70f

        for (y in yStart until yEnd step max(4, (h / 180).toInt())) {
            val x = w * .5f
            val p = avgPixel(b, x.toInt(), y, 3)
            val darkness = 1f - ((p[0] + p[1] + p[2]) / (255f * 3f))
            if (darkness > .38f) {
                val left = w * .05f
                val right = w * .95f
                val top = y.toFloat()
                val bottom = min(h * .70f, top + expected)
                if (bottom - top > minSide * .45f) {
                    val score = darkness
                    if (score > bestScore) {
                        bestScore = score
                        best = RectF2(left, top, right, bottom)
                    }
                }
            }
        }
        return best
    }

    private fun sampleBoard(b: Bitmap, r: RectF2): Array<BooleanArray> {
        val out = Array(8) { BooleanArray(8) }
        val cw = (r.right - r.left) / 8f
        val ch = (r.bottom - r.top) / 8f

        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val cx = r.left + (col + .5f) * cw
                val cy = r.top + (row + .5f) * ch
                val center = avgPixel(b, cx.toInt(), cy.toInt(), max(2, (cw * .12f).toInt()))
                val edge = avgPixel(
                    b,
                    (r.left + col * cw + cw * .12f).toInt(),
                    (r.top + row * ch + ch * .12f).toInt(),
                    max(1, (cw * .05f).toInt())
                )
                val saturation = saturation(center[0], center[1], center[2])
                val brightness = (center[0] + center[1] + center[2]) / 3f
                val edgeBrightness = (edge[0] + edge[1] + edge[2]) / 3f

                // Occupied blocks tend to have more saturation/brightness and
                // internal contrast than the dark empty cell.
                out[row][col] =
                    (saturation > .16f && brightness > 55f) ||
                    (brightness - edgeBrightness > 18f)
            }
        }
        return out
    }

    private fun detectTray(b: Bitmap): List<DetectedPiece> {
        // The tray is split into 3 horizontal zones. We use connected-ish
        // occupancy sampling with adaptive saturation rather than exact RGB.
        val result = mutableListOf<DetectedPiece>()
        val h = b.height
        val w = b.width
        val y0 = (h * .72f).toInt()
        val y1 = (h * .94f).toInt()

        for (slot in 0 until 3) {
            val x0 = (w * (slot / 3f) + w * .03f).toInt()
            val x1 = (w * ((slot + 1) / 3f) - w * .03f).toInt()
            val grid = Array(5) { BooleanArray(5) }

            for (r in 0 until 5) {
                for (c in 0 until 5) {
                    val x = x0 + ((c + .5f) / 5f * (x1 - x0)).toInt()
                    val y = y0 + ((r + .5f) / 5f * (y1 - y0)).toInt()
                    val p = avgPixel(b, x, y, max(2, w / 160))
                    grid[r][c] = saturation(p[0], p[1], p[2]) > .20f &&
                            (p[0] + p[1] + p[2]) / 3f > 70f
                }
            }

            val normalized = normalize(grid)
            if (normalized.isNotEmpty()) {
                val cells = normalized.flatMapIndexed { rr, row ->
                    row.mapIndexedNotNull { cc, v -> if (v) rr to cc else null }
                }
                result += DetectedPiece(cells, .72f)
            }
        }
        return result
    }

    private fun normalize(g: Array<BooleanArray>): Array<BooleanArray> {
        val rows = g.indices.filter { r -> g[r].any { it } }
        if (rows.isEmpty()) return emptyArray()
        val cols = g[0].indices.filter { c -> g.any { it[c] } }
        if (cols.isEmpty()) return emptyArray()
        return Array(rows.size) { rr ->
            BooleanArray(cols.size) { cc -> g[rows[rr]][cols[cc]] }
        }
    }

    private fun avgPixel(b: Bitmap, x0: Int, y0: Int, rad: Int): FloatArray {
        var r = 0f; var g = 0f; var bl = 0f; var n = 0
        for (y in max(0, y0 - rad)..min(b.height - 1, y0 + rad)) {
            for (x in max(0, x0 - rad)..min(b.width - 1, x0 + rad)) {
                val c = b.getPixel(x, y)
                r += ((c shr 16) and 255)
                g += ((c shr 8) and 255)
                bl += (c and 255)
                n++
            }
        }
        return floatArrayOf(r / n, g / n, bl / n)
    }

    private fun saturation(r: Float, g: Float, b: Float): Float {
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        return if (mx == 0f) 0f else (mx - mn) / mx
    }
}
