# Block Blast Live Helper v2.4

Polished Android helper for Block Blast.

## v2.4
- Premium-style compact main UI.
- Short labels: OVERLAY, AKSES GAME, MULAI LIVE, STOP.
- After screen-capture approval, Block Blast (`com.block.juggle`) opens automatically.
- Detection is gated by foreground-app verification using Usage Access.
- Detection and floating UI are hidden on Home and other apps.
- Visual overlay is pass-through; only the compact LIVE control accepts touch.
- Build target: Java/Kotlin 17, Gradle 8.11.1.

## Required setup
1. Enable **OVERLAY**.
2. Enable **AKSES GAME** in Android Usage Access.
3. Press **MULAI LIVE**.
4. Approve Android screen capture.
5. Block Blast opens automatically.

The Play Store listing identifies the official Block Blast package as `com.block.juggle`.
