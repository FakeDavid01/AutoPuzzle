package com.fakedavid.blockblasthelper

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

class ControlOverlayView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    var onDrag: ((Float, Float) -> Unit)? = null
    var onStop: (() -> Unit)? = null

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(238, 12, 17, 27)
        c.drawRoundRect(0f, 0f, w, h, 22f, 22f, paint)
        paint.color = Color.argb(255, 104, 232, 164)
        c.drawCircle(20f, h / 2f, 6f, paint)
        paint.color = Color.WHITE
        paint.textSize = 16f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        c.drawText("LIVE", 34f, h / 2f + 5f, paint)
        paint.color = Color.rgb(116, 126, 145)
        paint.textSize = 11f
        paint.typeface = Typeface.DEFAULT
        c.drawText("drag", 34f, h / 2f + 21f, paint)
        paint.color = Color.rgb(50, 60, 78)
        c.drawRoundRect(w - 70f, 7f, w - 7f, h - 7f, 16f, 16f, paint)
        paint.color = Color.rgb(255, 105, 115)
        paint.textSize = 12f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        c.drawText("STOP", w - 58f, h / 2f + 4f, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; moved = false; return true }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX; val dy = e.rawY - downY
                if (abs(dx) > 3 || abs(dy) > 3) moved = true
                if (moved) { onDrag?.invoke(dx, dy); downX = e.rawX; downY = e.rawY }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved && e.x >= width - 78f) onStop?.invoke()
                performClick(); return true
            }
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
