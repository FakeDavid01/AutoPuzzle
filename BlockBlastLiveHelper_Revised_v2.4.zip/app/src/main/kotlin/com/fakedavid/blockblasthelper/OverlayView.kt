package com.fakedavid.blockblasthelper

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.max

class OverlayView(context: Context) : View(context) {
    var detection: Detection? = null
        set(value) { field = value; invalidate() }
    var moves: List<Solver.Move> = emptyList()
        set(value) { field = value; invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isClickable = false
        isFocusable = false
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = detection
        val cardW = minOf(width - 36f, 330f)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(228, 10, 15, 24)
        c.drawRoundRect(18f, 18f, 18f + cardW, 78f, 18f, 18f, paint)
        paint.color = Color.rgb(104, 232, 164)
        c.drawCircle(42f, 48f, 7f, paint)
        paint.color = Color.WHITE
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 16f
        c.drawText(if (d == null) "LIVE  •  SCANNING" else "LIVE  •  ${(d.confidence * 100).toInt()}%" , 58f, 54f, paint)
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 11f
        paint.color = Color.rgb(128, 140, 160)
        c.drawText("BLOCK BLAST ONLY", 58f, 69f, paint)

        if (d == null) return
        val r = d.boardRect
        val cw = (r.right - r.left) / 8f
        val ch = (r.bottom - r.top) / 8f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = Color.argb(220, 104, 232, 164)
        c.drawRoundRect(r.left - 6f, r.top - 6f, r.right + 6f, r.bottom + 6f, 14f, 14f, paint)

        for ((i, m) in moves.withIndex()) {
            paint.style = Paint.Style.FILL
            paint.color = when (i) { 0 -> Color.argb(115, 104, 232, 164); 1 -> Color.argb(105, 100, 160, 255); else -> Color.argb(105, 255, 190, 80) }
            for ((dr, dc) in m.piece.cells) {
                val left = r.left + (m.col + dc) * cw
                val top = r.top + (m.row + dr) * ch
                c.drawRoundRect(left + 3, top + 3, left + cw - 3, top + ch - 3, 8f, 8f, paint)
            }
        }

        paint.style = Paint.Style.FILL
        paint.color = Color.argb(220, 10, 15, 24)
        c.drawRoundRect(r.left, r.top - 40f, r.left + 150f, r.top - 8f, 10f, 10f, paint)
        paint.color = Color.WHITE
        paint.textSize = 12f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        c.drawText("BOARD  ${(d.confidence * 100).toInt()}%", r.left + 10f, r.top - 19f, paint)
    }
}
