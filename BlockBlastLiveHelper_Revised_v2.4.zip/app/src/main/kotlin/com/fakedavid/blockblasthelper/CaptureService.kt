package com.fakedavid.blockblasthelper

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.WindowManager
import kotlin.math.max

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "START"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        private const val CHANNEL = "blockblast_live"
        private const val NOTIFICATION_ID = 9002
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var control: ControlOverlayView? = null
    private var controlParams: WindowManager.LayoutParams? = null
    private var windowManager: WindowManager? = null
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private var visibleForGame = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
            if (data != null && code == Activity.RESULT_OK && projection == null) startProjection(code, data)
        }
        return START_NOT_STICKY
    }

    private fun startProjection(code: Int, data: Intent) {
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Block Blast Live Helper")
            .setContentText("Live aktif • Block Blast only")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, notification)

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "BlockBlastLiveCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
        showOverlay()
        startForegroundGuard()

        reader?.setOnImageAvailableListener({ r ->
            if (!GameGuard.isBlockBlast(this)) {
                r.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            if (busy) {
                r.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            busy = true
            val image = r.acquireLatestImage()
            if (image != null) {
                try {
                    val plane = image.planes[0]
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val bmpWidth = width + rowPadding / pixelStride
                    val raw = Bitmap.createBitmap(bmpWidth, height, Bitmap.Config.ARGB_8888)
                    raw.copyPixelsFromBuffer(plane.buffer)
                    val bmp = Bitmap.createBitmap(raw, 0, 0, width, height)
                    raw.recycle()
                    val detection = Detector.detect(bmp)
                    if (detection != null) {
                        val moves = Solver.best(detection.board, detection.pieces)
                        handler.post {
                            overlay?.detection = detection
                            overlay?.moves = moves
                        }
                    }
                    bmp.recycle()
                } catch (_: Throwable) {
                } finally {
                    image.close()
                    busy = false
                }
            } else busy = false
        }, handler)
    }

    private fun startForegroundGuard() {
        handler.post(object : Runnable {
            override fun run() {
                val onGame = GameGuard.isBlockBlast(this@CaptureService)
                if (onGame != visibleForGame) {
                    visibleForGame = onGame
                    overlay?.visibility = if (onGame) android.view.View.VISIBLE else android.view.View.GONE
                    control?.visibility = if (onGame) android.view.View.VISIBLE else android.view.View.GONE
                    if (!onGame) {
                        overlay?.detection = null
                        overlay?.moves = emptyList()
                    }
                }
                handler.postDelayed(this, 450L)
            }
        })
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        overlay = OverlayView(this)
        val visualLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(overlay, visualLp)

        control = ControlOverlayView(this).apply {
            onDrag = { dx, dy ->
                val lp = controlParams ?: return@apply
                lp.x += dx.toInt(); lp.y += dy.toInt()
                try { wm.updateViewLayout(this, lp) } catch (_: Throwable) {}
            }
            onStop = { stopSelf() }
        }
        val cp = WindowManager.LayoutParams(196, 58, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            x = 18; y = 82
        }
        controlParams = cp
        wm.addView(control, cp)
        visibleForGame = GameGuard.isBlockBlast(this)
        overlay?.visibility = if (visibleForGame) android.view.View.VISIBLE else android.view.View.GONE
        control?.visibility = if (visibleForGame) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Block Blast Live Helper", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { control?.let { windowManager?.removeView(it) } } catch (_: Throwable) {}
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Throwable) {}
        control = null; overlay = null; controlParams = null; windowManager = null
        reader?.close(); reader = null
        virtualDisplay?.release(); virtualDisplay = null
        projection?.stop(); projection = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
