package com.fakedavid.blockblasthelper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var overlayButton: Button
    private lateinit var accessButton: Button

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                startCapture(result.resultCode, result.data!!)
            } else {
                status.text = "Capture dibatalkan"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshSetupState()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(28))
            setBackgroundColor(Color.rgb(9, 12, 20))
        }

        val scroll = ScrollView(this).apply { isFillViewport = true }
        scroll.addView(root)

        val brand = TextView(this).apply {
            text = "BLOCK BLAST"
            textSize = 13f
            setTextColor(Color.rgb(104, 232, 164))
            letterSpacing = .18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val title = TextView(this).apply {
            text = "LIVE HELPER"
            textSize = 32f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(2), 0, 0)
        }
        val subtitle = TextView(this).apply {
            text = "Smart board detection  •  v2.4"
            textSize = 13f
            setTextColor(Color.rgb(142, 151, 170))
            setPadding(0, dp(6), 0, dp(24))
        }

        status = TextView(this).apply {
            text = "READY"
            textSize = 12f
            setTextColor(Color.rgb(104, 232, 164))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            letterSpacing = .12f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(18, 25, 36))
        }

        val setupTitle = sectionTitle("SETUP")
        overlayButton = actionButton("OVERLAY") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        accessButton = actionButton("AKSES GAME") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        val liveTitle = sectionTitle("LIVE")
        val start = primaryButton("MULAI LIVE") {
            if (!Settings.canDrawOverlays(this)) {
                status.text = "AKTIFKAN OVERLAY DULU"
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@primaryButton
            }
            if (!GameGuard.hasUsageAccess(this)) {
                status.text = "AKTIFKAN AKSES GAME DULU"
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                return@primaryButton
            }
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
            captureLauncher.launch(mgr.createScreenCaptureIntent())
        }
        val stop = actionButton("STOP") {
            stopService(Intent(this, CaptureService::class.java))
            status.text = "STOPPED"
        }

        val note = TextView(this).apply {
            text = "Hanya aktif saat Block Blast berada di depan. Setelah izin capture diberikan, Block Blast dibuka otomatis. Saat kamu pindah aplikasi atau ke Home, deteksi dan floating UI otomatis disembunyikan."
            textSize = 13f
            setTextColor(Color.rgb(132, 141, 159))
            setPadding(0, dp(20), 0, 0)
        }

        root.addView(brand)
        root.addView(title)
        root.addView(subtitle)
        root.addView(status, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(24) })
        root.addView(setupTitle)
        root.addView(overlayButton, buttonLp())
        root.addView(accessButton, buttonLp())
        root.addView(liveTitle)
        root.addView(start, buttonLp())
        root.addView(stop, buttonLp())
        root.addView(note)

        setContentView(scroll)
        refreshSetupState()
    }

    private fun refreshSetupState() {
        if (!::overlayButton.isInitialized) return
        val overlayOk = Settings.canDrawOverlays(this)
        val accessOk = GameGuard.hasUsageAccess(this)
        overlayButton.text = if (overlayOk) "OVERLAY  ✓" else "OVERLAY"
        accessButton.text = if (accessOk) "AKSES GAME  ✓" else "AKSES GAME"
        if (overlayOk && accessOk) status.text = "READY  •  BLOCK BLAST ONLY"
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(Color.rgb(103, 115, 136))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        letterSpacing = .16f
        setPadding(0, dp(22), 0, dp(8))
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        isAllCaps = false
        gravity = Gravity.CENTER
        setBackgroundColor(Color.rgb(27, 35, 50))
        setOnClickListener { action() }
    }

    private fun primaryButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 14f
        setTextColor(Color.BLACK)
        isAllCaps = false
        gravity = Gravity.CENTER
        setBackgroundColor(Color.rgb(104, 232, 164))
        setOnClickListener { action() }
    }

    private fun buttonLp() = LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startCapture(resultCode: Int, data: Intent) {
        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_RESULT_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)

        // Launch from the visible Activity immediately after the user approved screen capture.
        val game = packageManager.getLaunchIntentForPackage(GameGuard.BLOCK_BLAST_PACKAGE)
        if (game != null) {
            game.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(game)
            status.text = "LIVE  •  OPENING BLOCK BLAST"
        } else {
            status.text = "BLOCK BLAST TIDAK TERPASANG"
        }
    }
}
